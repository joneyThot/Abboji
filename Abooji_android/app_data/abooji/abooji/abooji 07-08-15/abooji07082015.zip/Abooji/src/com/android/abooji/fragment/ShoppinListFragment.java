package com.android.abooji.fragment;

import com.android.abooji.R;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

public class ShoppinListFragment extends Fragment implements OnClickListener{
	View mRootView;
	Fragment fm;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,	Bundle savedInstanceState) {
		mRootView = inflater.inflate(R.layout.fragment_shopping_list, container, false);
		initview();
		return mRootView;
	}

	private void initview() {
		mRootView.findViewById(R.id.shoppinglist_editlist_btn).setOnClickListener(this);
		mRootView.findViewById(R.id.shoppinglist_shareshopping_btn).setOnClickListener(this);
		mRootView.findViewById(R.id.shoppinglist_addnewlist_btn).setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.shoppinglist_editlist_btn:
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new ShoppingListEditFragment()).commit();
			break;
		case R.id.shoppinglist_shareshopping_btn:
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new ShoppingShareFragment()).commit();
			break;
		case R.id.shoppinglist_addnewlist_btn:
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new ShoppingAddNewListFragment()).commit();
			break;
		}

	}

}
