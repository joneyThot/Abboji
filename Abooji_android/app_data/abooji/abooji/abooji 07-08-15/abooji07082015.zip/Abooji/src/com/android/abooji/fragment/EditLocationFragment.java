package com.android.abooji.fragment;

import com.android.abooji.R;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListView;
import android.widget.TextView;

public class EditLocationFragment extends Fragment implements OnClickListener,OnCheckedChangeListener {

	Fragment fr;
	View mRootView;
	CheckBox item_Check;
	ListView list_Location;
	TextView current_location_txt;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,	Bundle savedInstanceState) {
		mRootView = inflater.inflate(R.layout.fragment_edit_location, container, false);
		initview();
		return mRootView;
	}

	private void initview() {
		item_Check = (CheckBox) mRootView.findViewById(R.id.item_check);
		item_Check.setOnCheckedChangeListener(this);
		list_Location = (ListView) mRootView.findViewById(R.id.listview);
		current_location_txt = (TextView) mRootView.findViewById(R.id.edit_location_current_location_textview);
		mRootView.findViewById(R.id.edit_location_add_btn).setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.edit_location_add_btn:
//			FragmentManager fm = getFragmentManager();
//			FragmentTransaction fragmentTransaction = fm.beginTransaction();
//			fragmentTransaction.replace(R.id.fragment_place, fr);
//			fragmentTransaction.commit();
			break;

		default:
			break;
		}

	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if(isChecked){
			current_location_txt.setVisibility(View.VISIBLE);
			list_Location.setVisibility(View.VISIBLE);
		} else {
			current_location_txt.setVisibility(View.GONE);
			list_Location.setVisibility(View.GONE);
		}
	}
}