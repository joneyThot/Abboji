package com.android.abooji.fragment;

import com.android.abooji.R;
import com.android.abooji.logger.Logger;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ShoppingListEditFragment extends Fragment{
	View mRootView;
	Fragment fm;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,	Bundle savedInstanceState) {
		mRootView = inflater.inflate(R.layout.fragment_edit_shopping_lsit, container, false);
		initview();
		return mRootView;

	}

	private void initview() {
	}
	
}
