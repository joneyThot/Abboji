package com.android.abooji;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.android.abooji.service.Utils;

public class SplashActivity extends Activity 
{
	private Handler mHandler = new Handler();
	private Runnable mRunnable = new Runnable() 
	{
		@Override
		public void run() 
		{
			
			if((!Utils.sharedPreferences.getString(Utils.USER_EMAIL, "").isEmpty())&&(!Utils.sharedPreferences.getString(Utils.USER_PASSWORD, "").isEmpty()))
			{
				startActivity(new Intent(SplashActivity.this,DashboardLoginActivity.class));
				finish();
			}
			else //if((Utils.sharedPreferences.getString(Utils.USERNAME, "username")==null)&&(Utils.sharedPreferences.getString(Utils.PASSWORD, "password")==null))
			{
				startActivity(new Intent(SplashActivity.this,Login_RegisterActivity.class));
				finish();
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		getActionBar().hide();
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		Utils.sharedPreferences = this.getSharedPreferences(Utils.PREF_NAME, MODE_PRIVATE);
		mHandler.postDelayed(mRunnable, 2000);
	}
	@Override
	public void onBackPressed() 
	{
		super.onBackPressed();
		mHandler.removeCallbacks(mRunnable);
	}
}
