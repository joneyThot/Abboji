package com.android.abooji.fragment;

import com.android.abooji.R;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

public class EditCardFragment extends Fragment implements OnClickListener{
	Fragment fr;
	View mRootView;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,	Bundle savedInstanceState) {
		mRootView = inflater.inflate(R.layout.fragment_edit_card, container, false);
		initview();
		return mRootView;
	}

	private void initview() {
		mRootView.findViewById(R.id.fragment_edit_card_btn).setOnClickListener(this);
		mRootView.findViewById(R.id.fragment_edit_card_add_btn).setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.fragment_edit_card_btn:
			break;

		case R.id.fragment_edit_card_add_btn:
			break;
		}
	}
}
