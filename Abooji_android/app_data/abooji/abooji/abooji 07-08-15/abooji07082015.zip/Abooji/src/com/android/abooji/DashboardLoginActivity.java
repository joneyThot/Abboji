package com.android.abooji;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.FragmentManager.OnBackStackChangedListener;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.android.abooji.fragment.BarcodeFragment;
import com.android.abooji.fragment.CurrentLocationFragment;
import com.android.abooji.fragment.SearchFragment;
import com.android.abooji.fragment.ShoppinListFragment;
import com.android.abooji.fragment.SlidingMenuFragment;
import com.android.abooji.view.TextViewPlus;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu.OnOpenListener;

public class DashboardLoginActivity extends BaseActivity implements OnClickListener
{
	public DashboardLoginActivity() 
	{
		super(R.string.app_name);
	}

	TextViewPlus title;
	Fragment fr = null;
	boolean locPres=false;
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		getActionBar().hide();
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_logindashboard);
		initview();
		drawermenuFunction();
	}

	private void initview() 
	{

		findViewById(R.id.title).setVisibility(View.VISIBLE);
		findViewById(R.id.search_bar).setVisibility(View.VISIBLE);
		findViewById(R.id.drawer_icon).setVisibility(View.VISIBLE);
		title = (TextViewPlus)findViewById(R.id.title);
		setTitleText("");
		//title.setText(R.string.profile_txt);

		findViewById(R.id.search_bar).setOnClickListener(this);
		findViewById(R.id.drawer_icon).setOnClickListener(this);
		findViewById(R.id.homebtn).setOnClickListener(this);
		findViewById(R.id.eyebtn).setOnClickListener(this);
		findViewById(R.id.refereshbtn).setOnClickListener(this);
		findViewById(R.id.locationbtn).setOnClickListener(this);
		findViewById(R.id.barcodebtn).setOnClickListener(this);

		getSlidingMenu().setMode(SlidingMenu.LEFT);
		getSlidingMenu().setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.search_bar:
			locPres=false;
			setTitleText("SEARCH");
			this.getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new SearchFragment()).commit();
			break;
		case R.id.drawer_icon:
			locPres=false;
			showMenu();
			break;
		case R.id.homebtn:
			locPres=false;
			setTitleText("LOCATION");
			break;
		case R.id.eyebtn:
			locPres=false;
			setTitleText("SHOPPINGLIST");
			this.getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new ShoppinListFragment()).commit();
			break;
		case R.id.refereshbtn:
			locPres=false;
			break;
		case R.id.locationbtn:
			if (!locPres) {
				locPres=true;
				setTitleText("CURRENTLOCATION");
				this.getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new CurrentLocationFragment()).commit();
			}
			break;
		case R.id.barcodebtn:
			locPres=false;
			this.getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new BarcodeFragment()).commit();
			break;
		}
	}
	private void drawermenuFunction()
	{
		getSlidingMenu().setOnOpenListener(new OnOpenListener() {
			@Override
			public void onOpen() {
				SlidingMenuFragment.viewSelectedPosition();
			}
		});
	}
	@Override
	public void onBackPressed() 
	{
		getSupportFragmentManager().addOnBackStackChangedListener((android.support.v4.app.FragmentManager.OnBackStackChangedListener) getListener());
		if (getSlidingMenu().isMenuShowing()) 
		{
			getSlidingMenu().toggle();
		}
		else 
		{
			super.onBackPressed();
		}
	}
	private OnBackStackChangedListener getListener()
	{
		OnBackStackChangedListener result = new OnBackStackChangedListener()
		{
			public void onBackStackChanged() 
			{                   
				FragmentManager fm = getFragmentManager();
				Fragment fragment = null;
				if (fm != null)
				{
					fragment = (Fragment)fm.findFragmentById(R.id.logindash_contenframe);
					fragment.onResume();
				}                   
			}
		};

		return result;
	}
	/*private void FragmentReplaceFunction()
	{
		FragmentManager fm = getFragmentManager();
		FragmentTransaction fragmentTransaction = fm.beginTransaction();
		fragmentTransaction.replace(R.id.fragment_place, fr);
		fragmentTransaction.commit();
	}*/
	private void setTitleText(String titleTextString)
	{
		if(titleTextString.equals("SEARCH"))
		{
			title.setText(R.string.title_searchtxt);
		}
		else if(titleTextString.equals("LOCATION"))
		{
			title.setText(R.string.title_locationtext);
		}
		else if(titleTextString.equals("SHOPPINGLIST"))
		{
			title.setText(R.string.title_shoppinglisttext);
		}
		else if(titleTextString.equals("CURRENTLOCATION"))
		{
			title.setText(R.string.title_currentlocationtext);
		}
		else if(titleTextString.equals(""))
		{
			title.setText(R.string.title_profiletext);
		}
	}
	private void FragmentReplaceFunction()
	{
		FragmentManager fm = getFragmentManager();
		FragmentTransaction fragmentTransaction = fm.beginTransaction();
		fragmentTransaction.replace(R.id.fragment_place, fr);
		fragmentTransaction.commit();
	}
}