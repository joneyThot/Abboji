package com.android.abooji.fragment;

import com.android.abooji.R;
import com.android.abooji.logger.Logger;

import android.app.Fragment;
import android.app.FragmentManager.OnBackStackChangedListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;

public class ShoppingShareFragment extends Fragment implements OnClickListener{
	View mRootView;
	Fragment fm;
	EditText mEmail;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,	Bundle savedInstanceState) {
		mRootView = inflater.inflate(R.layout.fragment_email_address, container, false);
		initview();
		return mRootView;
	}

	private void initview() {
		mEmail = (EditText) mRootView.findViewById(R.id.email_address_edit);
		mRootView.findViewById(R.id.email_address_save_btn).setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		
	}
	
}
