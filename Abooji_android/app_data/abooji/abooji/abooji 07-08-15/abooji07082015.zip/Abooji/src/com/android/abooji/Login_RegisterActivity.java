package com.android.abooji;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class Login_RegisterActivity extends Activity implements OnClickListener
{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		getActionBar().hide();
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login_register);
		initView();
	}

	public void initView()
	{
		findViewById(R.id.login).setOnClickListener(this);
		findViewById(R.id.register).setOnClickListener(this);
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.login:
			Intent loginintent = new Intent(Login_RegisterActivity.this, LoginActivity.class);
			loginintent.putExtra("FROM", "LOGIN");
			startActivity(loginintent);
			//finish();
			break;
			
		case R.id.register:
			Intent registerintent = new Intent(Login_RegisterActivity.this, RegisterActivity.class);
			registerintent.putExtra("FROM", "REGISTER");
			startActivity(registerintent);
			//finish();
			break;
		}
	}
}
