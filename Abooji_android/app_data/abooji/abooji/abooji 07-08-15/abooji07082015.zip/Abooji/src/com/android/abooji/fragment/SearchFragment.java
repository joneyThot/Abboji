package com.android.abooji.fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.widget.EditText;

import com.android.abooji.R;
import com.android.abooji.logger.Logger;
import com.android.abooji.service.Utils;

public class SearchFragment extends Fragment implements OnClickListener
{
	Fragment fr;
	private View mRootView;
	EditText mKeyword_edittxt;
	@Override
	public View onCreateView(LayoutInflater inflater,ViewGroup container, Bundle savedInstanceState) 
	{
		mRootView = inflater.inflate(R.layout.fragment_search, container, false);
		initview();
		CheckFocus();
		return mRootView;
	}
	private void initview() 
	{
		mKeyword_edittxt = (EditText)mRootView.findViewById(R.id.search_keyword_edttxt);
		
		
		mRootView.findViewById(R.id.search_ResetBtn).setOnClickListener(this);
		mRootView.findViewById(R.id.search_search).setOnClickListener(this);
		mRootView.findViewById(R.id.search_keywordRemove).setOnClickListener(this);
	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId())
		{
		case R.id.search_ResetBtn:

			break;
		case R.id.search_search:

			break;
		case R.id.search_keywordRemove:
			Clearingdata(mKeyword_edittxt);
			break;

		}
	}
	public void Clearingdata(EditText edt)
	{
		Utils.clearData(edt);
	}
	private void CheckFocus()
	{
		mKeyword_edittxt.setOnFocusChangeListener(new OnFocusChangeListener() 
		{          
			@Override
			public void onFocusChange(View v, boolean hasFocus) 
			{
				hideShowFunction(mKeyword_edittxt,"SEARCH_KEYWORD");
			}
		});
	}
	
	private void hideShowFunction(final EditText objEdit, final String status)
	{
		objEdit.addTextChangedListener(new TextWatcher() 
		{

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) 
			{
				int i = objEdit.getText().toString().length();
				if(i<=0)
				{
					if(status.equals("SEARCH_KEYWORD"))
					{
						mRootView.findViewById(R.id.search_keywordRemove).setVisibility(View.GONE);
					}

				}
				else 
				{
					if(status.equals("SEARCH_KEYWORD"))
					{
						mRootView.findViewById(R.id.search_keywordRemove).setVisibility(View.VISIBLE);
					}
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,int after) 
			{

			}

			@Override
			public void afterTextChanged(Editable s) 
			{

			}
		});
	}
}