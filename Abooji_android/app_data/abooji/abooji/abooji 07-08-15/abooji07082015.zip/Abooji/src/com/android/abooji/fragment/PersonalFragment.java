package com.android.abooji.fragment;

import java.util.ArrayList;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ListView;

import com.android.abooji.R;
import com.android.abooji.adapter.DialogItemAdapter;
import com.android.abooji.model.ItemModel;
import com.android.abooji.view.TextViewPlus;

public class PersonalFragment extends Fragment implements OnClickListener
{
	Fragment fr;
	private View mRootView;
	TextViewPlus mChildrenAge;
	ListView mChildrenAgeList;
	Dialog dialog;
	DialogItemAdapter adapter;
	ArrayList<ItemModel> list = new ArrayList<ItemModel>();

	@Override
	public View onCreateView(LayoutInflater inflater,ViewGroup container, Bundle savedInstanceState) 
	{
		mRootView = inflater.inflate(R.layout.activity_personal, container, false);
		initview();
		return mRootView;
	}
	private void initview() 
	{
		mRootView.findViewById(R.id.activity_personal_next_btn).setOnClickListener(this);
		mRootView.findViewById(R.id.activity_personal_save_btn).setOnClickListener(this);

		mChildrenAge = (TextViewPlus) mRootView.findViewById(R.id.activity_personal_children_age_edittxt);
		mChildrenAge.setOnClickListener(this);
		
		getModel();

	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.activity_personal_next_btn:
			fr  = new CardFragment();
			FragmentReplaceFunction();
			break;

		case R.id.activity_personal_save_btn:
			break;

		case R.id.activity_personal_children_age_edittxt:
			openChildrenAgeDialog();
			break;

		case R.id.dialog_remove_btn:
			dialog.dismiss();
			break;

		}
	}
	private void openChildrenAgeDialog() {
		dialog = new Dialog(getActivity());
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.dialog_spinner);
		dialog.findViewById(R.id.dialog_remove_btn).setOnClickListener(this);
		mChildrenAgeList = (ListView) dialog.findViewById(R.id.categoryList);
		adapter = new DialogItemAdapter(getActivity(), list, mChildrenAge);
		mChildrenAgeList.setAdapter(adapter);
		adapter.notifyDataSetChanged();
		dialog.show();

	}

	private ArrayList<ItemModel> getModel() {
		list.add(new ItemModel("Infant"));
		list.add(new ItemModel("Toddler"));
		list.add(new ItemModel("Child"));
		list.add(new ItemModel("Teens"));
		list.add(new ItemModel("Young Adults"));
		list.add(new ItemModel("Adults"));

		return list;
	}
	private void FragmentReplaceFunction()
	{
		FragmentManager fm = getFragmentManager();
		FragmentTransaction fragmentTransaction = fm.beginTransaction();
		fragmentTransaction.replace(R.id.fragment_place, fr);
		fragmentTransaction.commit();
	}
}