package com.android.abooji.fragment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;

import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AdapterView.OnItemClickListener;

import com.android.abooji.R;
import com.android.abooji.service.PlaceDetailsJSONParser;
import com.android.abooji.service.PlaceJSONParser;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class LocationFragment extends Fragment implements OnClickListener
{
	Fragment fr;
	View mRootView;
	int hwidth,hHeight;
	AutoCompleteTextView atvPlaces;
	DownloadTask placesDownloadTask;
	DownloadTask placeDetailsDownloadTask;
	ParserTask placesParserTask;
	ParserTask placeDetailsParserTask;
	GoogleMap googleMap;
	final int PLACES = 0;
	final int PLACES_DETAILS = 1;
	Marker marker;
	ArrayList<Marker> marraylst_marker = new ArrayList<Marker>();
	LatLng point;
	Button ok, cancel;
	double latitude = 0.0, longitude = 0.0;
	Dialog mapDialog;
	EditText mLocationName, mLocationLatLong;

	@Override
	public View onCreateView(LayoutInflater inflater,ViewGroup container, Bundle savedInstanceState) 
	{
		mRootView = inflater.inflate(R.layout.activity_location, container, false);
		Display display = getActivity().getWindowManager().getDefaultDisplay(); 

		hwidth = display.getWidth();  // deprecated
		hHeight = display.getHeight(); 
		initview();
		return mRootView;
	}
	private void initview() 
	{
		mRootView.findViewById(R.id.activity_location_prev_btn).setOnClickListener(this);
		mRootView.findViewById(R.id.activity_location_next_btn).setOnClickListener(this);
		mRootView.findViewById(R.id.activity_location_open_map_btn).setOnClickListener(this);
		mLocationName = (EditText) mRootView.findViewById(R.id.activity_name_of_location_edittxt);
		mLocationLatLong = (EditText) mRootView.findViewById(R.id.activity_location_edittxt);
		
	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.activity_location_prev_btn:
			fr  = new CategoryFragment();
			FragmentReplaceFunction();
			break;

		case R.id.activity_location_next_btn:
			fr = new NotificationFragment();
			FragmentReplaceFunction();
			break;

		case R.id.activity_location_open_map_btn:
			openMapDialog();
			break;

		case R.id.add_btn:
			break;

		case R.id.close_btn:
			mapDialog.dismiss();
			break;
		}
	}
	private void openMapDialog() {
		mapDialog = new Dialog(getActivity());
		mapDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mapDialog.setContentView(R.layout.fragment_current_location);
		mapDialog.findViewById(R.id.rl1).setVisibility(View.VISIBLE);
		mapDialog.findViewById(R.id.current_location_add_btn).setVisibility(View.GONE);
		mapDialog.findViewById(R.id.add_btn).setOnClickListener(this);
		mapDialog.findViewById(R.id.close_btn).setOnClickListener(this);
		atvPlaces = (AutoCompleteTextView) mapDialog.findViewById(R.id.atv_places);
		atvPlaces.setThreshold(1);

		if(googleMap == null){
			FragmentManager myFM = getActivity().getFragmentManager();
			final MapFragment myMAPF = (MapFragment) myFM.findFragmentById(R.id.map);
			googleMap = myMAPF.getMap();
			googleMap.clear();
			googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
		} 

		mapinit();
		mapDialog.getWindow().setLayout((hwidth/2)+200, (hHeight/2)+100);
		mapDialog.show();

	}

	private void mapinit() {

		atvPlaces.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {

				if (atvPlaces.length() == 0) {
					if (!marraylst_marker.isEmpty()) {
						googleMap.clear();
						marker.remove();
						marraylst_marker.clear();
					}
				}
				placesDownloadTask = new DownloadTask(PLACES);
				String url = getAutoCompleteUrl(s.toString());
				placesDownloadTask.execute(url);
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
			}
		});

		atvPlaces.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int index,
					long id) {

				ListView lv = (ListView) arg0;
				SimpleAdapter adapter = (SimpleAdapter) arg0.getAdapter();

				HashMap<String, String> hm = (HashMap<String, String>) adapter
						.getItem(index);
				placeDetailsDownloadTask = new DownloadTask(PLACES_DETAILS);
				String url = getPlaceDetailsUrl(hm.get("reference"));
				placeDetailsDownloadTask.execute(url);

			}
		});
	}

	private String getAutoCompleteUrl(String place) {
		String key = "key=AIzaSyAU93CCu4spbwvIXmAtbcvn-VDUMei4wTo";
		String input = "input=" + place;
		String types = "types=geocode";
		String sensor = "sensor=false";
		String parameters = input + "&" + types + "&" + sensor + "&" + key;
		String output = "json";
		String url = "https://maps.googleapis.com/maps/api/place/autocomplete/"	+ output + "?" + parameters;
		return url;
	}

	private String getPlaceDetailsUrl(String ref) {
		String key = "key=AIzaSyAU93CCu4spbwvIXmAtbcvn-VDUMei4wTo";
		String reference = "reference=" + ref;
		String sensor = "sensor=false";
		String parameters = reference + "&" + sensor + "&" + key;
		String output = "json";
		String url = "https://maps.googleapis.com/maps/api/place/details/" + output + "?" + parameters;
		Log.i("URL", "url :: " + url);
		return url;
	}

	private String downloadUrl(String strUrl) throws IOException {
		String data = "";
		InputStream iStream = null;
		HttpURLConnection urlConnection = null;
		try {
			URL url = new URL(strUrl);
			urlConnection = (HttpURLConnection) url.openConnection();
			urlConnection.connect();
			iStream = urlConnection.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
			StringBuffer sb = new StringBuffer();
			String line = "";
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
			data = sb.toString();
			br.close();

		} catch (Exception e) {
			Log.d("Exception while downloading url", e.toString());
		} finally {
			iStream.close();
			urlConnection.disconnect();
		}
		return data;
	}

	private class DownloadTask extends AsyncTask<String, Void, String> {
		private int downloadType = 0;

		public DownloadTask(int type) {
			this.downloadType = type;
		}

		@Override
		protected String doInBackground(String... url) {
			String data = "";
			try {
				data = downloadUrl(url[0]);
			} catch (Exception e) {
				Log.d("Background Task", e.toString());
			}
			return data;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			switch (downloadType) {
			case PLACES:
				placesParserTask = new ParserTask(PLACES);
				placesParserTask.execute(result);
				break;

			case PLACES_DETAILS:
				placeDetailsParserTask = new ParserTask(PLACES_DETAILS);
				placeDetailsParserTask.execute(result);
			}
		}
	}

	private class ParserTask extends
	AsyncTask<String, Integer, List<HashMap<String, String>>> {
		int parserType = 0;

		public ParserTask(int type) {
			this.parserType = type;
		}

		@Override
		protected List<HashMap<String, String>> doInBackground(
				String... jsonData) {

			JSONObject jObject;
			List<HashMap<String, String>> list = null;

			try {
				jObject = new JSONObject(jsonData[0]);

				switch (parserType) {
				case PLACES:
					PlaceJSONParser placeJsonParser = new PlaceJSONParser();
					list = placeJsonParser.parse(jObject);
					break;
				case PLACES_DETAILS:
					PlaceDetailsJSONParser placeDetailsJsonParser = new PlaceDetailsJSONParser();
					list = placeDetailsJsonParser.parse(jObject);
				}

			} catch (Exception e) {
				Log.d("Exception", e.toString());
			}
			return list;
		}

		@Override
		protected void onPostExecute(List<HashMap<String, String>> result) {

			switch (parserType) {
			case PLACES:
				String[] from = new String[] { "description" };
				int[] to = new int[] { android.R.id.text1 };
				// Creating a SimpleAdapter for the AutoCompleteTextView
				SimpleAdapter adapter = new SimpleAdapter(getActivity(),result, android.R.layout.simple_list_item_1, from, to);
				// Setting the adapter
				atvPlaces.setAdapter(adapter);
				break;
			case PLACES_DETAILS:
				HashMap<String, String> hm = result.get(0);
				latitude = Double.parseDouble(hm.get("lat"));
				longitude = Double.parseDouble(hm.get("lng"));
				FragmentManager myFM = getActivity().getFragmentManager();
				final MapFragment myMAPF = (MapFragment) myFM.findFragmentById(R.id.map);
				googleMap = myMAPF.getMap();
				point = new LatLng(latitude, longitude);
				Log.i("LATLANG", "Latitude : " + latitude + " & Longitude : "+ longitude);
				CameraPosition cameraPosition = new CameraPosition.Builder().target(point).zoom(12).build();
				googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
				MarkerOptions options = new MarkerOptions();
				options.position(point);
				options.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ROSE));
				options.title("Position");
				options.snippet("Latitude:" + latitude + ",Longitude:"+ longitude);
				marker = googleMap.addMarker(options);
				marraylst_marker.add(marker);
				mLocationName.setText(atvPlaces.getText().toString().trim());
				mLocationLatLong.setText(""+ latitude + "," + longitude );
				break;
			}
		}
	}

	private void FragmentReplaceFunction()
	{
		FragmentManager fm = getFragmentManager();
		FragmentTransaction fragmentTransaction = fm.beginTransaction();
		fragmentTransaction.replace(R.id.fragment_place, fr);
		fragmentTransaction.commit();
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		if (googleMap != null) {
			getActivity().getFragmentManager().beginTransaction().remove(getActivity().getFragmentManager().findFragmentById(R.id.map)).commit();
			googleMap = null;
		}
	}
}