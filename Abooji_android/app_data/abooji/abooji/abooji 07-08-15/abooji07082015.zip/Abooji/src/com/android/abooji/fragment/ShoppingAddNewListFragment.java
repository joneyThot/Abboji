package com.android.abooji.fragment;

import com.android.abooji.R;
import com.android.abooji.logger.Logger;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;

public class ShoppingAddNewListFragment extends Fragment implements OnClickListener{
	View mRootView;
	Fragment fm;
	EditText addNewList;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,	Bundle savedInstanceState) {
		mRootView = inflater.inflate(R.layout.fragment_add_new_shopping_list, container, false);
		initview();
		return mRootView;
	}

	private void initview() {
		mRootView.findViewById(R.id.add_new_shopping_list_add_btn).setOnClickListener(this);
		addNewList = (EditText) mRootView.findViewById(R.id.add_new_shopping_list_edittext);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.add_new_shopping_list_add_btn:

			break;
		}
	}

}