package com.android.abooji.fragment;

import java.util.ArrayList;

import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.abooji.R;
import com.android.abooji.adapter.CardTypeAdapter;
import com.android.abooji.model.CardTypeModel;
import com.android.abooji.service.AsyncCallListener;
import com.android.abooji.service.GetCardTypeRequestTask;
import com.android.abooji.service.Utils;

public class CardFragment extends Fragment implements OnClickListener
{
	Fragment fr;
	private View mRootView;
	Spinner mCardTypeSpinner;
	ListView mCardTypeList;
	CardTypeAdapter mCardTypeAdapter;
	private ArrayList<CardTypeModel> mCardTypeModel = new ArrayList<CardTypeModel>();
	Dialog dialog;
	
	@Override
	public View onCreateView(LayoutInflater inflater,ViewGroup container, Bundle savedInstanceState) 
	{
		mRootView = inflater.inflate(R.layout.activity_cards, container, false);
		initview();
		return mRootView;
	}
	private void initview() 
	{
		mRootView.findViewById(R.id.activity_cards_prev_btn).setOnClickListener(this);
		mRootView.findViewById(R.id.activity_cards_next_btn).setOnClickListener(this);
		mCardTypeSpinner = (Spinner) mRootView.findViewById(R.id.activity_cards_type_spinner);
		openCardType();

	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.activity_cards_prev_btn:
			fr  = new PersonalFragment();
			FragmentReplaceFunction();
			break;

		case R.id.activity_cards_next_btn:
			fr = new CategoryFragment();
			FragmentReplaceFunction();
			break;

//		case R.id.activity_cards_type_spinner:
//			openCardType();
//			dialog = new Dialog(getActivity());
//			openDialogForNewEvent(dialog);
//			dialog.show();

//			break;

		}
	}


//	private void openDialogForNewEvent(final Dialog dialog) 
//	{	
//		openCardType();
//		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//		dialog.setContentView(R.layout.dialog_spinner);
//		mCardTypeList = (ListView)dialog.findViewById(R.id.card_type_listview);
//			
//	}



	private void openCardType() {
		if(Utils.checkInternetConnection(getActivity())){
			GetCardTypeRequestTask getCardTypeRequestTask = new GetCardTypeRequestTask(getActivity());
			getCardTypeRequestTask.setAsyncCallListener(new AsyncCallListener() {
				@Override
				public void onResponseReceived(Object response) {
					mCardTypeModel = (ArrayList<CardTypeModel>) response;
					if(mCardTypeModel != null){

						mCardTypeAdapter = new CardTypeAdapter(getActivity(), mCardTypeModel);
						mCardTypeSpinner.setAdapter(mCardTypeAdapter);
					}
				}
				@Override
				public void onErrorReceived(String error) {
					Toast.makeText(getActivity(), getString(R.string.try_again), Toast.LENGTH_SHORT).show();
				}
			});
			getCardTypeRequestTask.execute();
		}else{
			Utils.showMessageDialog(getActivity(), getResources().getString(R.string.alert), 
					getResources().getString(R.string.connection));
		}

	}
	private void FragmentReplaceFunction()
	{
		FragmentManager fm = getFragmentManager();
		FragmentTransaction fragmentTransaction = fm.beginTransaction();
		fragmentTransaction.replace(R.id.fragment_place, fr);
		fragmentTransaction.commit();
	}
	

}