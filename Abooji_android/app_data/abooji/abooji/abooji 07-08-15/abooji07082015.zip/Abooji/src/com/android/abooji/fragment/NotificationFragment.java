package com.android.abooji.fragment;

import java.util.ArrayList;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ListView;

import com.android.abooji.LoginActivity;
import com.android.abooji.R;
import com.android.abooji.adapter.DialogItemAdapter;
import com.android.abooji.model.ItemModel;
import com.android.abooji.view.TextViewPlus;

public class NotificationFragment extends Fragment implements OnClickListener 
{
	Fragment fr;
	private View mRootView;
	TextViewPlus mAlerTiming;
	ListView mAlerTimeList;
	Dialog dialog;
	DialogItemAdapter adapter;
	ArrayList<ItemModel> list = new ArrayList<ItemModel>();

	@Override
	public View onCreateView(LayoutInflater inflater,ViewGroup container, Bundle savedInstanceState) 
	{
		mRootView = inflater.inflate(R.layout.activity_notification_alert, container, false);
		initview();
		return mRootView;
	}
	private void initview() 
	{
		mRootView.findViewById(R.id.activity_notification_alert_next_btn).setOnClickListener(this);
		mRootView.findViewById(R.id.activity_notification_alert_prev_btn).setOnClickListener(this);
		mAlerTiming = (TextViewPlus) mRootView.findViewById(R.id.activity_notification_alert_timings_edittxt);
		mAlerTiming.setOnClickListener(this);
		
		getModel();
	}
	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.activity_notification_alert_next_btn:
			startActivity(new Intent(getActivity(),LoginActivity.class));
			getActivity().finish();
			break;

		case R.id.activity_notification_alert_prev_btn:
			fr = new LocationFragment();
			FragmentReplaceFunction();
			break;
			
		case R.id.activity_notification_alert_timings_edittxt:
			openAlertTimingDialog();
			break;

		case R.id.dialog_remove_btn:
			dialog.dismiss();
			break;
		}
	}
	private void openAlertTimingDialog() {
		dialog = new Dialog(getActivity());
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.dialog_spinner);
		dialog.findViewById(R.id.dialog_remove_btn).setOnClickListener(this);
		mAlerTimeList = (ListView) dialog.findViewById(R.id.categoryList);
		adapter = new DialogItemAdapter(getActivity(), list, mAlerTiming);
		mAlerTimeList.setAdapter(adapter);
		adapter.notifyDataSetChanged();
		dialog.show();
		
	}
	
	private ArrayList<ItemModel> getModel() {
		list.add(new ItemModel("06:00 - 07:00"));
		list.add(new ItemModel("07:00 - 08:00"));
		list.add(new ItemModel("08:00 - 09:00"));
		list.add(new ItemModel("09:00 - 10:00"));
		list.add(new ItemModel("10:00 - 11:00"));
		list.add(new ItemModel("11:00 - 12:00"));
		list.add(new ItemModel("12:00 - 13:00"));
		list.add(new ItemModel("13:00 - 14:00"));
		list.add(new ItemModel("14:00 - 15:00"));
		list.add(new ItemModel("15:00 - 16:00"));
		list.add(new ItemModel("16:00 - 17:00"));
		list.add(new ItemModel("17:00 - 18:00"));
		list.add(new ItemModel("18:00 - 19:00"));
		list.add(new ItemModel("19:00 - 20:00"));
		list.add(new ItemModel("20:00 - 21:00"));
		list.add(new ItemModel("21:00 - 22:00"));
		list.add(new ItemModel("22:00 - 23:00"));
		list.add(new ItemModel("23:00 - 24:00"));
		list.add(new ItemModel("24:00 - 01:00"));
		list.add(new ItemModel("01:00 - 02:00"));
		list.add(new ItemModel("02:00 - 03:00"));
		list.add(new ItemModel("03:00 - 04:00"));
		list.add(new ItemModel("04:00 - 05:00"));
		list.add(new ItemModel("05:00 - 06:00"));
		
		return list;
	}
	
	
	private void FragmentReplaceFunction()
	{
		FragmentManager fm = getFragmentManager();
		FragmentTransaction fragmentTransaction = fm.beginTransaction();
		fragmentTransaction.replace(R.id.fragment_place, fr);
		fragmentTransaction.commit();
	}
}