package com.android.abooji.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import com.android.abooji.DashboardLoginActivity;
import com.android.abooji.R;
import com.android.abooji.service.Utils;
import com.android.abooji.view.TextViewPlus;

public class SlidingMenuFragment extends Fragment implements OnClickListener
{
	public static View mRoot;

	private static LinearLayout mMenuLayout;
	public static ScrollView sc;
	public static int pos_x = 0, pos_y = 0;
	Fragment fr = null;
	TextViewPlus titleText;
	boolean locpressed=false;
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		mRoot = inflater.inflate(R.layout.list, null);
		mMenuLayout = (LinearLayout) mRoot.findViewById(R.id.menuLayout);
		titleText = (TextViewPlus)getActivity().findViewById(R.id.title);
		sc = (ScrollView)mRoot.findViewById(R.id.scrollLayout);
		
		sc.post(new Runnable() 
		{
			@Override
			public void run() 
			{
				pos_x = sc.getScrollX();
				pos_y = sc.getScrollY();
			}
		});

		for (int i = 1; i < mMenuLayout.getChildCount(); i++) 
		{
			if(i != 11)
			{
				mMenuLayout.getChildAt(i).setOnClickListener(this);
			}
		}

		return mRoot;
	}

	@Override
	public void onClick(View view) 
	{
		sc.post(new Runnable() 
		{
			@Override
			public void run() 
			{
				pos_x = sc.getScrollX();
				pos_y = sc.getScrollY();
				//				sc.scrollTo(pos_x, pos_y);
			}
		});

		//((TextView) view).setBackgroundResource(R.drawable.sidemenu_active_bg1);
		switch (view.getId()) 
		{
		case R.id.menu_homebtn:
			//getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new LocationFragment()).commit();
			titleText.setText(R.string.profile_txt);
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new LocationFragment()).commit();
			break;

		case R.id.menu_barcodebtn:
			//titleText.setText();
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new BarcodeFragment()).commit();
			//getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new MyprofileFragment()).commit();
			break;

		case R.id.menu_logoutbtn:
			//getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new MyprofileFragment()).commit();
			
			Utils.storeString(Utils.USER_EMAIL, "");
			Utils.storeString(Utils.USER_PASSWORD, "");
			Utils.storeBoolean(Utils.LOGINSTATUS, false);
			getActivity().finish();
			break;

		case R.id.menu_edit_profilebtn:
			titleText.setText(R.string.title_editprofiletext);
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new PersonalFragment()).commit();
			break;

		case R.id.menu_edit_cardsbtn:
			titleText.setText(R.string.title_editcardtext);
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new EditCardFragment()).commit();
			break;

		case R.id.menu_edit_locationbtn:
			titleText.setText(R.string.title_editlocationtext);
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new EditLocationFragment()).commit();
			break;

		case R.id.menu_edit_shopinglistbtn:
			titleText.setText(R.string.title_editshoppinglisttext);
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new ShoppingListEditFragment()).commit();
			break;

		case R.id.menu_edit_categorybtn:
			titleText.setText(R.string.title_editcategorytext);
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new CategoryFragment()).commit();
			break;

		case R.id.menu_edit_notificationbtn:
			titleText.setText(R.string.title_editnotificationtext);
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new NotificationFragment()).commit();
			break;

		case R.id.menu_changepasswordbtn:
			titleText.setText(R.string.title_changepasswordtext);
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new ChangePasswordFragment()).commit();
			break;

		case R.id.menu_helpbtn:
			titleText.setText(R.string.title_helptext);
			getActivity().getFragmentManager().beginTransaction().replace(R.id.logindash_contenframe, new HelpFragment()).commit();
			break;
			
		default:
			break;
				
		}
		((DashboardLoginActivity) getActivity()).getSlidingMenu().toggle();
		
		
	}

	public static void viewSelectedLayout(boolean org, int pos, int pos2) 
	{
		if(org)
		{
			//((TextView) mMenuLayout.getChildAt(pos)).setBackgroundResource(R.drawable.sidemenu_active_bg1);
			//((TextView) mMenuLayout.getChildAt(21)).setCompoundDrawablesWithIntrinsicBounds(R.drawable.menuitem_arrow_active, 0, 0, 0);
		}
		/*else if(!org)
		{
			((TextView) mMenuLayout.getChildAt(pos)).setBackgroundResource(R.drawable.sidemenu_active_bg1);
			if(pos != pos2)
			{
				((TextView) mMenuLayout.getChildAt(pos2)).setBackgroundResource(R.drawable.sidemenu_normal_bg1);
			}
			//			((TextView) mMenuLayout.getChildAt(1)).setCompoundDrawablesWithIntrinsicBounds(R.drawable.menuitem_arrow_active, 0, 0, 0);
		}*/
	}
	public static void viewSelectedPosition() 
	{
		sc.post(new Runnable() 
		{ 
			public void run() { 
				//				pos_x = sc.getScrollX();
				//				pos_y = sc.getScrollY();
				sc.scrollTo(pos_x, pos_y);
			} 
		});
	}
}
