package com.android.abooji.model;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class CardTypeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@SerializedName("user_id")
	public String id = "";

	@SerializedName("card_type_title")
	public String card_type_title = "";

	@SerializedName("status")
	public String status = "";

}
